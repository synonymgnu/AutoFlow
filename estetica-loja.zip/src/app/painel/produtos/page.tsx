import Link from "next/link";
import { requireStoreRole } from "@/lib/permissions";
import { brl } from "@/lib/format";
import { alternarStatus, excluirProduto, getProdutosPaginados } from "./actions";
import { ConfirmButton } from "@/components/painel/confirm-button";

export const dynamic = "force-dynamic";

interface PageProps {
  searchParams: Promise<{ page?: string }> | { page?: string };
}

export default async function ProdutosPage({ searchParams }: PageProps) {
  const { store, role } = await requireStoreRole();
  const resolvedParams = await searchParams;
  const currentPage = Number(resolvedParams?.page) || 1;

  const { products, totalPages, totalCount } = await getProdutosPaginados(
    store.id,
    currentPage
  );

  return (
    <>
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-bold tracking-tight">
          Produtos ({totalCount})
        </h1>
        <Link
          href="/painel/produtos/novo"
          className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-ink hover:brightness-110"
        >
          Novo produto
        </Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl border border-line bg-white">
        <table className="w-full min-w-[40rem] text-left text-sm">
          <thead className="border-b border-line bg-paper/60 text-ink/60">
            <tr>
              <th className="px-4 py-3 font-medium">Produto</th>
              <th className="px-4 py-3 font-medium">Variantes</th>
              <th className="px-4 py-3 font-medium">Situação</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {products.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-ink/60">
                  Nenhum produto cadastrado nesta página.
                </td>
              </tr>
            )}
            {products.map((p) => (
              <tr key={p.id} className="align-top">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {p.images[0] ?? p.imageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={p.images[0] ?? p.imageUrl ?? ""}
                        alt=""
                        className="h-12 w-12 rounded border border-line object-cover"
                      />
                    ) : (
                      <div className="h-12 w-12 rounded bg-paper" />
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="font-medium">{p.name}</p>
                      <p className="text-ink/55 truncate">
                        {p.brandRef?.name ?? p.brand ?? "Sem marca"}
                      </p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-ink/80">
                  {p.variants.map((v) => (
                    <p key={v.id}>
                      {v.name}: {brl(v.price)}
                      {role === "OWNER" && (
                        <>
                          {" "}
                          ·{" "}
                          <span className={v.stock <= 5 ? "text-warn" : ""}>
                            {v.stock} un.
                          </span>
                        </>
                      )}
                    </p>
                  ))}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      p.status === "ACTIVE"
                        ? "bg-green-100 text-ok"
                        : "bg-slate-100 text-ink/70"
                    }`}
                  >
                    {p.status === "ACTIVE" ? "Publicado" : "Rascunho"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Link
                      href={`/painel/produtos/${p.id}`}
                      className="rounded-lg border border-line px-3 py-1.5 text-xs hover:bg-paper"
                    >
                      Editar
                    </Link>
                    <form action={alternarStatus}>
                      <input type="hidden" name="id" value={p.id} />
                      <button className="rounded-lg border border-line px-3 py-1.5 text-xs hover:bg-paper">
                        {p.status === "ACTIVE" ? "Despublicar" : "Publicar"}
                      </button>
                    </form>
                    {role === "OWNER" && (
                      <form action={excluirProduto}>
                        <input type="hidden" name="id" value={p.id} />
                        <ConfirmButton
                          message={`Excluir "${p.name}" definitivamente? Os pedidos antigos continuam no histórico.`}
                          className="rounded-lg border border-red-200 px-3 py-1.5 text-xs text-red-700 hover:bg-red-50"
                        >
                          Excluir
                        </ConfirmButton>
                      </form>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* NAVEGAÇÃO DE PAGINAÇÃO */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-line px-4 py-3">
            <p className="text-sm text-ink/70">
              Página <span className="font-semibold text-ink">{currentPage}</span> de{" "}
              <span className="font-semibold text-ink">{totalPages}</span>
            </p>

            <div className="flex gap-2">
              {currentPage > 1 ? (
                <Link
                  href={`/painel/produtos?page=${currentPage - 1}`}
                  className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium hover:bg-paper"
                >
                  Anterior
                </Link>
              ) : (
                <span className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium text-ink/30 cursor-not-allowed">
                  Anterior
                </span>
              )}

              {currentPage < totalPages ? (
                <Link
                  href={`/painel/produtos?page=${currentPage + 1}`}
                  className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium hover:bg-paper"
                >
                  Próxima
                </Link>
              ) : (
                <span className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium text-ink/30 cursor-not-allowed">
                  Próxima
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}